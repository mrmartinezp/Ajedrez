package Principal;

import java.util.ArrayList;

import Principal.Ficha.Color;
import Principal.Ficha.Shape;

public class Reina extends Ficha {

	public Reina(Color color, Tablero t, Coordenada c) {
		super();
		this.posicion = c;
		this.color = color;
		this.tablero = t;

		if (color == Color.Negro) {
			this.shape = shape.Black_Queen;
		} else
			this.shape = shape.White_Queen;

		t.getCelda(posicion).setFicha(this);
	}

	public ArrayList<Coordenada> movimientosPosibles() {

		ArrayList<Coordenada> lista = new ArrayList<Coordenada>();
		Coordenada c;

		// ARRIBA//
		c = posicion.moverDiagonalArribaIzquierda();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverDiagonalAbajoIzquierda();
		}

		// ARRIBA//
		c = posicion.moverDiagonalArribaDerecho();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverDiagonalAbajoDerecho();
		}

		// ABAJO//
		c = posicion.moverDiagonalAbajoIzquierda();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverDiagonalAbajoIzquierda();
		}

		// ABAJO//
		c = posicion.moverDiagonalArribaDerecho();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverDiagonalAbajoDerecho();
		}

		// ARRIBA//
		c = posicion.moverArriba();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverArriba();
		}

		// ABAJO//
		c = posicion.moverAbajo();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverAbajo();
		}

		// DERECHA//
		c = posicion.moverDerecha();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverDerecha();
		}

		// IZQUIERDA//
		c = posicion.moverIzquierda();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverIzquierda();
		}

		return lista;

	}

}
