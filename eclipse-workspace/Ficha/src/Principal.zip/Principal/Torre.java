package Principal;

import java.util.ArrayList;

public class Torre extends Ficha {

	public Torre(Color color, Tablero t, Coordenada c) {
		super();
		this.posicion = c;
		this.color = color;
		this.tablero = t;

		if (color == Color.Negro) {
			this.shape = shape.Black_Torre;
		} else
			this.shape = shape.White_Torre;

		t.getCelda(posicion).setFicha(this);
	}

	public ArrayList<Coordenada> movimientosPosibles() {

		ArrayList<Coordenada> lista = new ArrayList<Coordenada>();
		Coordenada c;

		// ARRIBA//
		c = posicion.moverArriba();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverArriba();
		}

		// ABAJO//
		c = posicion.moverAbajo();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverAbajo();
		}

		// DERECHA//
		c = posicion.moverDerecha();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverDerecha();
		}

		// IZQUIERDA//
		c = posicion.moverIzquierda();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverIzquierda();
		}

		return lista;

	}
}
