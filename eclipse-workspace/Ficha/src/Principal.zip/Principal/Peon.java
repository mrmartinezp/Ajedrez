package Principal;

import java.util.ArrayList;
import java.util.Iterator;

import Principal.Ficha.Color;
import Principal.Ficha.Shape;

public class Peon extends Ficha {

	public Peon(Color color, Tablero t, Coordenada c) {
		super();
		this.posicion = c;
		this.color = color;
		this.tablero = t;

		if (color == Color.Negro) {
			this.shape = shape.Black_Peon;
		} else
			this.shape = shape.White_Peon;

		t.getCelda(posicion).setFicha(this);
	}

	public ArrayList<Coordenada> movimientosPosibles() {

		ArrayList<Coordenada> lista = new ArrayList<Coordenada>();
		Coordenada c;

		// ARRIBA//
		c = posicion.moverArriba();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverArriba();
		}
		return lista;
	}
	
	
	
}
