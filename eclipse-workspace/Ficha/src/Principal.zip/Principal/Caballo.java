package Principal;

import java.util.ArrayList;

import Principal.Ficha.Color;
import Principal.Ficha.Shape;

public class Caballo extends Ficha{
	
	public Caballo(Color color,Tablero t, Coordenada c) {
		super();
		this.posicion=c;
		this.color=color;
		this.tablero=t;
		
		if(color == Color.Negro) {
			this.shape= shape.Black_Caballo;
		}else
			this.shape= shape.White_Caballo;		
	
		t.getCelda(posicion).setFicha(this);
	}

	
	public ArrayList<Coordenada> movimientosPosibles() {

		ArrayList<Coordenada> lista = new ArrayList<Coordenada>();
		Coordenada c;

		// IZQUIERDAARRIBA//
		c = posicion.moverIzquierda().moverArriba();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverIzquierda().moverArriba();
		}

		// ARRIBAIZQUIERDA//
		c = posicion.moverArriba().moverIzquierda();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverArriba().moverIzquierda();
		}

		// IZQUIERDAABAJO//
		c = posicion.moverIzquierda().moverAbajo();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverIzquierda().moverAbajo();
		}
				
		// ABAJOIZQUIERDA//
		c = posicion.moverAbajo().moverIzquierda();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverAbajo().moverIzquierda();
		}
		
		
		// ARRIBADERECHA//
		c = posicion.moverArriba().moverDerecha();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverArriba().moverDerecha();
		}
		
		// DERECHAARRIBA//
		c = posicion.moverDerecha().moverArriba();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverDerecha().moverArriba();
		}
		
		
		// DERECHAABAJO//
		c = posicion.moverDerecha().moverAbajo();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverDerecha().moverAbajo();
		}
		
		// ABAJODERECHA//
		c = posicion.moverAbajo().moverDerecha();
		while (tablero.comprobarEstaDentro(c) == true && tablero.getCelda(c).getFicha() == null) {
			lista.add(c);
			c = c.moverAbajo().moverDerecha();
		}		
		
		return lista;

	}
}
