package Principal;

import java.util.Scanner;

import Principal.Ficha.Color;
import Principal.Ficha.Shape;

public class Test {

	public static void main(String[] args) {

		Tablero t = new Tablero();
		// showMenu();


		Torre torre = new Torre(Ficha.Color.Blanco, t, new Coordenada('F', 8));
		System.out.println(torre.movimientosPosibles());
		torre.moverFicha(new Coordenada('F',5));
		
		
		

		//System.out.println(torre.moverFicha('E',2));
		System.out.println(t.toString());

	}

	public static void showMenu() {

		Scanner sc = new Scanner(System.in);

		System.out.println();
		System.out.println("BIENVENIDO AL JUEGO DEL AJEDREZ");
		System.out.println("|___|___|___|___|___|___|___|___|");
		System.out.println("  |___|___|___|___|___|___|___|");
		System.out.println();
		System.out.println("QUIERES JUGAR?  SI(1)/NO(2)");
		int opcion = sc.nextInt();
		System.out.println();
		System.out.println("SALIR PULSA 0");
		System.out.println();

	}

	public static void moverFicha() {

		Scanner sc = new Scanner(System.in);
		System.out.println("Dame la posicion de la ficha que quiere mover");
		int pos1 = sc.nextInt();
		int pos2 = sc.nextInt();

		System.out.println("Dame la nueva posicion");
		int nuevaPos1 = sc.nextInt();
		int nuevaPos2 = sc.nextInt();

		// t.getFicha(pos1, pos2);
	}

}
