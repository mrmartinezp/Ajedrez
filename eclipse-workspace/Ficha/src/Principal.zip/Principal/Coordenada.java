package Principal;

public class Coordenada {

	private char letra;
	private int numero;

	public Coordenada(char letra, int numero) {
		super();
		this.letra = letra;
		this.numero = numero;
	}

	@Override
	public String toString() {
		return letra + "" + numero;
	}

	public Coordenada moverDerecha() {
		return new Coordenada(letra, numero + 1);
	}

	public Coordenada moverIzquierda() {
		return new Coordenada(letra, numero - 1);
	}

	public Coordenada moverArriba() {
		return new Coordenada((char) (letra - 1), numero);
	}

	public Coordenada moverAbajo() {
		return new Coordenada((char) (letra + 1), numero);
	}

	public Coordenada moverDiagonalArribaIzquierda() {
		return (moverArriba().moverIzquierda());
	}

	public Coordenada moverDiagonalArribaDerecho() {
		return (moverArriba().moverDerecha());
	}

	public Coordenada moverDiagonalAbajoIzquierda() {
		return (moverAbajo().moverIzquierda());
	}

	public Coordenada moverDiagonalAbajoDerecho() {
		return (moverAbajo().moverDerecha());
	}

	public char getLetra() {
		return letra;
	}

	public void setLetra(char letra) {
		this.letra = letra;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

}
