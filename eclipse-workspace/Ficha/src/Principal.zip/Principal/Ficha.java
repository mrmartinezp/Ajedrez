package Principal;

import java.util.ArrayList;

public abstract class Ficha {

	public static enum Shape {
		White_Queen("\u2655", Color.Blanco), White_King("\u2654", Color.Blanco), White_Alfil("\u2657", Color.Blanco),
		White_Caballo("\u2658", Color.Blanco), White_Torre("\u2656", Color.Blanco), White_Peon("\u2659", Color.Blanco),

		Black_Queen("\u265B", Color.Blanco), Black_King("\u265A", Color.Blanco), Black_Alfil("\u265D", Color.Blanco),
		Black_Caballo("\u265E", Color.Blanco), Black_Torre("\u265C", Color.Blanco), Black_Peon("\u265F", Color.Blanco);

		private String forma;
		private Color color;

		Shape(String forma, Color color) {
			this.forma = forma;
			this.color = color;
		}

		public String getForma() {
			return this.name();
		}

		public String toString() {
			return forma;
		}
	}

	public static enum Color {
		Blanco, Negro;
	}

	@Override
	public String toString() {
		return shape.toString();
	}

	protected Shape shape;
	protected Color color;
	protected Tablero tablero;
	protected Coordenada posicion;
	protected abstract ArrayList<Coordenada> movimientosPosibles();
	
	public Color getColor() {
		// TODO Auto-generated method stub
		return color;
	}
	public boolean moverFicha(Coordenada c) {
	
		System.out.println(movimientosPosibles());
			if(movimientosPosibles().contains(c) == true) {
				tablero.matar(tablero.getCelda(c).getFicha());
				
				tablero.getCelda(c).setFicha(this);
				tablero.getCelda(posicion).setFicha(null);
				posicion=c;
				return true;				
		}else
			return false;
	}

	
}

