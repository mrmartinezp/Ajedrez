package Principal;

public class Celda {

	private Ficha ficha;
	
	public Celda(Ficha ficha) {
		this.ficha=ficha;
		
	}
	
	public Celda() {

		this.ficha=null;
	}
	
	public boolean isEmpty() {
		if(ficha==null)
			return true;
		else
			return false;
	}
	

	public void setFicha(Ficha ficha) {
		this.ficha = ficha;
	}
	

	public Ficha getFicha() {
		return ficha;
	}

	@Override
	public String toString() {
		if(isEmpty())
			return " ";
		else
			return ficha.toString();
	}
	
	
}
